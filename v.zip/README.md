<div align=center>
 
# 🚀 Condi boatnet Ver 1 🚀

<p>
 <img src="https://img.shields.io/github/stars/hoaan1995/Condi-Boatnet?color=%23DF0067&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/forks/hoaan1995/Condi-Boatnet?color=%239999FF&style=for-the-badge"/> &nbsp;
 <img src="https://img.shields.io/github/license/hoaan1995/Condi-Boatnet?color=%23E8E8E8&style=for-the-badge"/> &nbsp;
 
</p>

<p align="center">  <a href="https://t.me/learneverything9"><img width="160" height="50" src="https://i.imgur.com/N7AK7XY.png"></a></p>

## Language</br>

 <img src="https://img.shields.io/badge/Go-00ADD8?style=for-the-badge&logo=go&logoColor=white"/> <img src="https://img.shields.io/badge/C-00599C?style=for-the-badge&logo=c&logoColor=white"/> <img src="https://img.shields.io/badge/Python-FFD43B?style=for-the-badge&logo=python&logoColor=blue"/> <img src="https://img.shields.io/badge/Shell_Script-121011?style=for-the-badge&logo=gnu-bash&logoColor=white"/>
 </div>
 
 ## Logs</br>
 - VERSION 1 RELEASE!


# README ♥️
Thanks for using it.<br>
Please help me press the STAR button thanks a lot<br>
If you encounter any errors or problems during installation, please contact me to quickly fix it!!!


# Setup
```sh
PLS DELETE FILE "DELETEME.txt" in loader/bins, dlr/release
READ Setup.txt file
```

# TOS:
```sh
What you use it for is up to you, we do not take any responsibility for this action
```

# CONTACT:
```sh
Telegram: @zxcr9999
```
